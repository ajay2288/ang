import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StepFromComponent } from './step-from.component';

describe('StepFromComponent', () => {
  let component: StepFromComponent;
  let fixture: ComponentFixture<StepFromComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StepFromComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StepFromComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
