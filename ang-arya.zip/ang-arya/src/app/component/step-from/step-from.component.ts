import { Component, OnInit } from '@angular/core';
import {NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {FormBuilder, FormGroup, FormArray, Validators} from '@angular/forms';


@Component({
  selector: 'app-step-from',
  templateUrl: './step-from.component.html',
  styleUrls: ['./step-from.component.less']
})
export class StepFromComponent implements OnInit {
  public isOpenRight = false;
  public isFormSet = false;
  // public isLinear = false;
  skillsForm: FormGroup;
  //public secondFormGroup: FormGroup;

  constructor(private modalService: NgbModal, private fb: FormBuilder) {}
  

  ngOnInit() {
    this.skillsForm = this.fb.group({
   
      skills: this.fb.array([]) ,
    });

    for(let i=0;i<5;i++){
      this. addSkills()
    }
   
  }

  get skills() : FormArray {
    return this.skillsForm.get("skills") as FormArray
  }

  newSkill(): FormGroup {
    return this.fb.group({
      skill: '',
    
    })
  }

  addSkills() {
    this.skills.push(this.newSkill());
  }
 
  removeSkill(i:number) {
    this.skills.removeAt(i);
  }

 


 
  public openRight(){
    this.isOpenRight = !this.isOpenRight;
  }



// get step2() : FormArray {
//   return this.orderForm.get("step2") as FormArray
// }



  public openModel(content:any) {
    this.modalService.open(content,
          {
            scrollable: true,
            windowClass: 'myCustomModalClass',
            // keyboard: false,
            // backdrop: 'static'
          }).result.then((result) => {
            console.log(result);
          },(reason) => {
          });
    
   
    
    
    }
}
