import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import {FormBuilder, FormGroup, FormArray, Validators} from '@angular/forms';
import { Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-step2-component',
  templateUrl: './step2-component.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./step2-component.component.less']
})
export class Step2ComponentComponent implements OnInit {
  public stepTwoFB: FormGroup;
  public illness: any = null;
  public selectedIndex  = 0;
  public selectedIllness:any[] = [];
  public selectedDisease: any = null;
  public questionIndex  = 0;
  diseasesOptions: any[] = ["Acute Lymphoblastic Leukemia - (All)","Acute Myeloid Leukemia - (AML)","Adrenocortical Carcinoma - Body Region"];
  @Output() sendItemParent = new EventEmitter();
  @Output() sendQuizIndex = new EventEmitter();
  constructor(private fb: FormBuilder, private cd: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.generateForm();
  }

  handleSave(){
    let obj = {
      name: this.stepTwoFB.value.disease,
      illness: this.illness,
      treatment: this.stepTwoFB.value.treatment,
      question: this.stepTwoFB.value.question
    }
    this.selectedIllness.push(obj)
    this.selectedDisease = null;
    this.stepTwoFB.controls.disease.setValue(null);
    this.stepTwoFB.controls.treatment.setValue(null);
    this.stepTwoFB.controls.question.setValue(null);
  }

  updateSelectedDisease(event:any){
    this.selectedDisease = event;
  }

  handleIllness(e:any){
    console.log("illness",e.source.value);
    this.illness = e.source.value;
  }
  
  handleStepSubmit(index:any){
    this.selectedIndex = index;
    console.log("Return",index);
    let data = {
      data: this.selectedIllness,
      stepIndex: 3
    }
    this.sendQuizIndex.emit({
      index: index, step: 2
    });
    
    this.sendItemParent.emit(data);
  }

  handleRemoveDisease(item:any){
    var filteredAry = this.selectedIllness.filter(e => e.name !== item)
    this.selectedIllness = filteredAry;
    this.cd.detectChanges();
  }

  generateForm(){
    this.stepTwoFB = this.fb.group({
      illness: null,
      disease: null,
      treatment: null,
      question: null,
      skill: null,
    });
  }

}
