import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, FormArray, Validators} from '@angular/forms';
import { Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-step1-component',
  templateUrl: './step1-component.component.html',
  styleUrls: ['./step1-component.component.less']
})
export class Step1ComponentComponent implements OnInit {
  public stepOneFB: FormGroup;
  public selectedIndex  = 0;
  public questionIndex  = 0;
  @Output() sendItemParent = new EventEmitter();
  @Output() sendQuizIndex = new EventEmitter();
  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.generateForm();
  }

  handleSubmit(index:any){
    this.selectedIndex = index;
    this.sendQuizIndex.emit({
      index: index, step: 1
    });
  }
  
  handleStepSubmit(index:any){
    console.log("Return",);
    let data = {
      data: this.stepOneFB.value,
      stepIndex: 2
    }
    this.sendQuizIndex.emit({
      index: index, step: 1
    });
    this.sendItemParent.emit(data);
  }

  generateForm(){
    this.stepOneFB = this.fb.group({
      name: '',
      born: '',
      gender: '',
      feet: '',
      cm: '',
      weight: '',

    });
  }

}
