import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-step3-component',
  templateUrl: './step3-component.html',
  styleUrls: ['./step3-component.less']
})
export class Step3ComponentComponent implements OnInit {
  public stepThreeFB: FormGroup;
  public illness: any = null;
  public selectedIndex = 0;
  faceInformation: File[] = [];
  bodyFrontInformation: File[] = [];
  bodyBackInformation: File[] = [];
  videoInformation: File[] = [];
  @Output() sendItemParent = new EventEmitter();
  @Output() sendQuizIndex = new EventEmitter();
  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.generateForm();
  }

  handleSubmit(index: any) {
    console.log("index", index);
    this.selectedIndex = index;
    this.sendQuizIndex.emit({
      index: index, step: 3
    });
  }

  onSelect(event: any, type: any) {
    console.log("event.addedFiles",event.addedFiles)
    let fileName = event.addedFiles[0].name;
    if (type == 'face') {
      this.faceInformation.push(...event.addedFiles);
      this.stepThreeFB.controls.faceInformation.setValue(fileName);
    }
    if (type == 'bodyback') {
      this.bodyBackInformation.push(...event.addedFiles);
      this.stepThreeFB.controls.bodyBackInformation.setValue(fileName);
    }
    if (type == 'bodyfront') {
      this.bodyFrontInformation.push(...event.addedFiles);
      this.stepThreeFB.controls.bodyFrontInformation.setValue(fileName);
    }
    if (type == 'video') {
      this.videoInformation.push(...event.addedFiles);
      this.stepThreeFB.controls.videoInformation.setValue(fileName);
    }

  }

  onRemove(event: any, type: any) {
    if(type == 'face'){
      this.faceInformation.splice(this.faceInformation.indexOf(event), 1);
      this.stepThreeFB.controls.faceInformation.setValue(null);
    } 
    if(type == 'bodyback'){
      this.bodyBackInformation.splice(this.bodyBackInformation.indexOf(event), 1);
      this.stepThreeFB.controls.bodyBackInformation.setValue(null);
    } 
    if(type == 'bodyfront'){
      this.bodyFrontInformation.splice(this.bodyFrontInformation.indexOf(event), 1);
      this.stepThreeFB.controls.bodyFrontInformation.setValue(null);
    } 
    if(type == 'video'){
      this.videoInformation.splice(this.videoInformation.indexOf(event), 1);
      this.stepThreeFB.controls.videoInformation.setValue(null);
    } 
  }


  handleStepSubmit(index: any) {
    console.log("Return", this.stepThreeFB.value);
    let data = {
      data: this.stepThreeFB.value,
      stepIndex: 4
    }
    this.sendItemParent.emit(data);
    this.sendQuizIndex.emit({
      index: index, step: 3
    });
  }

  generateForm() {
    this.stepThreeFB = this.fb.group({
      faceInformation: this.faceInformation,
      bodyBackInformation: this.bodyBackInformation,
      bodyFrontInformation: this.bodyFrontInformation,
      videoInformation: this.videoInformation,
      medicalInformation: null,
      medicalType: null,
      appSearch: null,
      hospitalSearch: null,
      wearables: null,
      wearablesSearch: null,
      health: null,
      healthSearch: null,

    });
  }

}
