import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.less']
})
export class DetailsComponent implements OnInit {
  allData:any = sessionStorage.getItem('formData');
  constructor() {
    
  }
  ngOnInit() {
    this.allData = JSON.parse(this.allData);
  }
}
