import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './component/header/header.component';
import { SidebarComponent } from './component/sidebar/sidebar.component';
import { StepFromComponent } from './component/step-from/step-from.component';
import { DetailsComponent } from './component/details/details.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatNativeDateModule} from '@angular/material/core';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {DemoMaterialModule} from './material-module';
import { Step1ComponentComponent } from './component/step=form/step1-component/step1-component.component';
import { Step2ComponentComponent } from './component/step=form/step2-component/step2-component.component';
import { Step3ComponentComponent } from './component/step=form/step3-component/step3-component';
import { Step4ComponentComponent } from './component/step=form/step4-component/step4-component';
import { NgxDropzoneModule } from 'ngx-dropzone';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    DetailsComponent,
    StepFromComponent,
    Step1ComponentComponent,
    Step2ComponentComponent,
    Step3ComponentComponent,
    Step4ComponentComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    DemoMaterialModule,
    NgxDropzoneModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
