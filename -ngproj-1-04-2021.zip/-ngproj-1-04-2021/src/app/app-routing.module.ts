import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StepFromComponent } from './component/step-from/step-from.component';
import { DetailsComponent } from './component/details/details.component';
const routes: Routes = [
  { 
    path:'home',
    component:StepFromComponent
},
  { 
    path:'details',
    component:DetailsComponent
},
{ 
  path:'',
  redirectTo:'home',
  pathMatch:'full'
},
{ 
  path:'**',
  redirectTo:'home',
  pathMatch:'full'
}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
