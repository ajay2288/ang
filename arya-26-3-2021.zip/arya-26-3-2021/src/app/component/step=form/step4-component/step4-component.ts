import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, FormArray, Validators} from '@angular/forms';
import { Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-step4-component',
  templateUrl: './step4-component.html',
  styleUrls: ['./step4-component.less']
})
export class Step4ComponentComponent implements OnInit {
  public stepFourFB: FormGroup;
  public selectedIndex  = 0;
  @Output() sendItemParent = new EventEmitter();
  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.generateForm();
  }

  handleSubmit(index:any){
    this.selectedIndex = index;
  }

  
  handleStepSubmit(){
    console.log("Redirect User to Next Page");
    let data = {
      data: this.stepFourFB.value,
      stepIndex: 5
    }
    this.sendItemParent.emit(data);
  }

  generateForm(){
    this.stepFourFB = this.fb.group({
      example: null,
      exampleQuestion: null,
      exampleText: null,
    });
  }

}
