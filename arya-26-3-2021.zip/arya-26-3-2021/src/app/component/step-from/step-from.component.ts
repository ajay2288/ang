import { Component, OnInit } from '@angular/core';
import {NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {Router} from "@angular/router"


@Component({
  selector: 'app-step-from',
  templateUrl: './step-from.component.html',
  styleUrls: ['./step-from.component.less']
})
export class StepFromComponent implements OnInit {
  public isOpenRight = false;
  public isFormSet = false;
  public allFormData:any = {
    step1Info: null,
    step2Info: null,
    step3Info: null,
    step4Info: null,
  }
  stepFirst = true;
  stepSecond = false;
  stepThird = false;
  stepFourth = false;
  // public isLinear = false;
  public selectedStep  = 1;
  public step1Quiz  = 0;
  public step2Quiz  = 0;
  public step3Quiz  = 0;
  public step4Quiz  = 0;
  configObj = {
    step1:5,
    step2: 1,
    step3: 6,
    step4: 3,
    height: 150
  }
  //public secondFormGroup: FormGroup;

  constructor(private modalService: NgbModal, private router: Router) {}
  ngOnInit() {
  }

  handleStepEvent(index:any){
    if(this.stepFirst && index === 1 || this.stepSecond && index === 2 || this.stepThird && index === 3 || this.stepFourth && index === 4){
      this.selectedStep = index
    };
  }

  getQuizIndex(obj:any){
    console.log("getQuizIndex",obj);
    if(obj.step == 1)
      this.step1Quiz = obj.index;
    if(obj.step == 2)
      this.step2Quiz = obj.index;
    if(obj.step == 3)
      this.step3Quiz = obj.index;
  }

  getStepTop(item:any, total:any){
    let totalheight = this.configObj.height;
    let singleHeight = this.configObj.height/total;
    return singleHeight * item +1 + 'px';
  }
  getStepHeight(item:any, total:any){
    let totalheight = this.configObj.height;
    let singleHeight = this.configObj.height/total;
    return singleHeight + 'px';
  }



  getStepIndex(items:any){
    console.log("Data From Child", items);
    this.selectedStep = items.stepIndex;
    switch(items.stepIndex) {
      case 2:
        this.stepSecond = true;
        this.allFormData.step1Info = items.data;
        break;
      case 3:
        this.stepThird = true;
        this.allFormData.step2Info = items.data;
        break;
      case 4:
        this.stepFourth = true;
        this.allFormData.step3Info = items.data;
        break;
      case 5:
          this.allFormData.step4Info = items.data;
          this.router.navigate(['/details']);
          break;
      default:
        this.stepFirst = true;
    }
    sessionStorage.setItem('formData',JSON.stringify(this.allFormData));
  }

 
  public openRight(){
    this.isOpenRight = !this.isOpenRight;
  }

  public openModel(content:any) {
    this.modalService.open(content,
          {
            scrollable: true,
            windowClass: 'myCustomModalClass',
            // keyboard: false,
            // backdrop: 'static'
          }).result.then((result) => {
            console.log(result);
          },(reason) => {
          });
    
   
    
    
    }
}
